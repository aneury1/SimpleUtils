#pragma once
#include "include/simpleutils/linkList.h"
